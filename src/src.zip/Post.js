import React, { useEffect, useState } from 'react'
import './post.css'
import Avatar from '@mui/material/Avatar';
import {db} from './App'
import firebase from 'firebase/compat/app';

function Post({postId,currentuser, username,caption,imageUrl}) {

  const [comments,setComments]= useState([]);
  const [comment,setComment]= useState('');

  useEffect (()=> {
     if(postId){
       return ()=>{
         db
          .collection('posts')
           .doc(postId)
           .collection('comments')
           .orderBy('timestamp','asc')
           .onSnapshot((snapshot) => {
             setComments(snapshot.docs.map((doc) => doc.data()))
           })
       }
     }


  },[postId])

  const postcomment =(e)=> {
    e.preventDefault();
    db.collection('posts').doc(postId).collection('comments').add({
      text: comment,
      username: currentuser.displayName,
      timestamp: firebase.firestore.FieldValue.serverTimestamp(),
    })
    setComment('')
  }
  return (
    <div className='post'>
        <div className='post_headerpart'>
            <Avatar
              className='post_avatar'
              src="https://cdn1.iconfinder.com/data/icons/user-interface-design-flat/60/017_-_Male_User-ui-user-interface-avatar-512.png"
              />
        <h3>{username}</h3>
        </div>
        
        <img className="post_img" src={imageUrl}/>
       <h4 className='post_text'><strong>{username}-</strong>{caption}</h4>
       {/* comment part */}

       <div className='posttt'>
           {
             comments.map((n)=>(
               <p>
                 <strong> {n.username}: </strong> {n.text}
               </p>
              
             ))
           }


       </div>
       {currentuser &&(
         <form className='post_comment_box'>
         <input
         value={comment}
         className='Post_comment'
         type='text'
         placeholder='Add comment here'
         onChange={(e) =>{
          setComment(e.target.value)
         }}
         />
         <button 
         className='Comment_btn'
         disabled={!comment}
         type="submit"
         onClick={postcomment}
         > Post
         </button> 
         
       </form>

       )}

       
    </div>
  )
}

export default Post